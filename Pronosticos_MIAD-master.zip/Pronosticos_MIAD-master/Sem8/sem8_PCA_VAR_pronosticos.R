############PCA & VAR
##### Principal component analysis
library(MTS)
options(digits = 4) 
###
da=read.table("m-amdur.txt",header=T)
head(da)
tail(da)
dur=da[,3:6]/1000
tdx=da[,1]+da[,2]/12
MTSplot(dur,tdx)
VARorder(dur) #Ser�a un VAR(4), pero la metodolog�a especifica ir corriendo cada modelo VAR(p) de uno al 4.
#m=VAR(dur)  
#MTSdiag(m)
#PCA
V0=princomp(dur)
summary(V0)
M0=matrix(V0$loadings[,1:4],4,4) ## eigenvectors
M0
##Modelo VAR1
m1=VAR(dur,1)  ## VAR(1) 
##PCA residuales
V1=princomp(m1$residuals)
summary(V1)
##Loadings
M1=matrix(V1$loadings[,1:4],4,4)
M1
##Modelo VAR2
m2=VAR(dur,2)  ## VAR(2) fit
##PCA residuales
V2=princomp(m2$residuals)
summary(V2)
##Loadings
M2=matrix(V2$loadings[,1:4],4,4)
M2
##Modelo VAR3
m3=VAR(dur,3)  ## VAR(2) fit
##PCA residuales
V3=princomp(m3$residuals)
summary(V3)
##Loadings
M3=matrix(V3$loadings[,1:4],4,4)
M3
##Modelo VAR4
m4=VAR(dur,4)  ## VAR(2) fit
##PCA residuales
V4=princomp(m4$residuals)
summary(V4)
##Loadings
M4=matrix(V4$loadings[,1:4],4,4)
M4
#####
M1 # Loading Matrix residuales del VAR(1)
M1 # Loading Matrix residuales del VAR(2)
M3 # Loading Matrix residuales del VAR(3)
M4 # Loading Matrix residuales del VAR(4)

###################################################
h4=matrix(c(1,0,-1,-1),4,1)
b0=m1$Ph0
t(h4)%*%(b0)
t(h4)%*%m1$Phi

###Con el h1:
h1=matrix(c(1,0,1,1),4,1)
t(h1)%*%m1$Phi
b0=m1$Ph0
t(h1)%*%(b0)
t(h1)%*%m1$Phi


##VAR Modelos
m2=VAR(dur,2)   ### VAR(2) fit

V2=princomp(m2$residuals)
summary(V2)

M2=matrix(V2$loadings[,1:4],4,4)
print(round(M0,3))

print(round(M1,3))

print(round(M2,3))
##########################################################

